ENTWICKLUNGSARTEFAKTE – NICHT FLASHEN
R2/R8 des physischen Boards sowie vorhandenes Bootloader- und Partitionslayout sind nicht bestätigt. Nur Anwendungen, kein komplettes Installations-/Recovery-Paket. Keine Nordic-DFU-/UF2-Dateien. Keine Upload-/Formatierungsbefehle. Hardware UNTESTED.
